import React, { Component } from "react";

export default class CreateRoomPage extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <p>This is the create room page</p>;
  }
}
